export interface FinancialMetric {
  label: string;
  fy23: string;
  fy24: string;
  change: string;
  trend: 'up' | 'down' | 'neutral';
}

export interface CitationInfo {
  documentId: string;
  documentName: string;
  page: number;
  snippet: string;
  verified: boolean;
  sectionTitle?: string;
  confidenceScore?: number;
  highlightedMetrics?: { label: string; value: string }[];
  auditRef?: string;
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  timestamp: string;
  citation?: CitationInfo;
  confidenceIndicator?: {
    verified: boolean;
    label: string;
  };
  metrics?: FinancialMetric[];
}

export interface FinancialDocument {
  id: string;
  name: string;
  size: string;
  pages: number;
  uploadDate: string;
  status: 'indexed' | 'indexing' | 'ready';
  type: 'Annual Report' | 'Quarterly Filing' | 'Audit' | 'Earnings' | 'Investor';
  description: string;
  keyHighlights: string[];
}

export type AccentColor = 'emerald' | 'electric-blue';
export type ViewMode = 'live' | 'mockup-16x9' | 'split-view';
export type ColorTheme = 'dark-navy' | 'light';
