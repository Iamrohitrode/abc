import React, { useState } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { ChatPanel } from './components/ChatPanel';
import { CitationDrawer } from './components/CitationDrawer';
import { UploadModal } from './components/UploadModal';
import { MockupPresentationView } from './components/MockupPresentationView';
import { INITIAL_DOCUMENTS, INITIAL_CHAT_MESSAGES, FINANCIAL_KNOWLEDGE_BASE } from './data/mockData';
import { FinancialDocument, ChatMessage, CitationInfo, AccentColor, ColorTheme, ViewMode } from './types';
import mockupImage from './assets/images/fininsight_ui_mockup_1791554991562.jpg';

export default function App() {
  const [documents, setDocuments] = useState<FinancialDocument[]>(INITIAL_DOCUMENTS);
  const [selectedDocId, setSelectedDocId] = useState<string>('doc-1');
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>(INITIAL_CHAT_MESSAGES);
  const [accent, setAccent] = useState<AccentColor>('emerald');
  const [theme, setTheme] = useState<ColorTheme>('dark-navy');
  const [viewMode, setViewMode] = useState<ViewMode>('live');
  const [activeCitation, setActiveCitation] = useState<CitationInfo | null>(null);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isStreaming, setIsStreaming] = useState(false);

  const activeDoc = documents.find((d) => d.id === selectedDocId) || documents[0];

  const handleSendMessage = (text: string) => {
    const userMsg: ChatMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setChatMessages((prev) => [...prev, userMsg]);
    setIsStreaming(true);

    // Simulate smart financial verification & retrieval
    setTimeout(() => {
      const lower = text.toLowerCase();
      let responseText = '';
      let citationData: CitationInfo | undefined = undefined;
      let metricsData = undefined;

      if (lower.includes('margin') || lower.includes('operating')) {
        const item = FINANCIAL_KNOWLEDGE_BASE['margin'];
        responseText = item.text;
        citationData = item.citation;
        metricsData = item.metrics;
      } else if (lower.includes('risk') || lower.includes('factor')) {
        const item = FINANCIAL_KNOWLEDGE_BASE['risk'];
        responseText = item.text;
        citationData = item.citation;
      } else if (lower.includes('debt') || lower.includes('liquidity') || lower.includes('cash')) {
        const item = FINANCIAL_KNOWLEDGE_BASE['liquidity'];
        responseText = item.text;
        citationData = item.citation;
        metricsData = item.metrics;
      } else if (lower.includes('cloud') || lower.includes('arr') || lower.includes('retention')) {
        const item = FINANCIAL_KNOWLEDGE_BASE['cloud'];
        responseText = item.text;
        citationData = item.citation;
        metricsData = item.metrics;
      } else if (lower.includes('revenue') || lower.includes('growth') || lower.includes('2024')) {
        responseText =
          'Revenue for FY2024 reached **$2.5 billion**, representing a **15% increase** year-over-year compared to FY2023. Key growth catalyst was **enterprise cloud subscription acceleration** (+28.4%).';
        citationData = {
          documentId: activeDoc.id,
          documentName: activeDoc.name,
          page: 42,
          sectionTitle: 'Operational Financial Summary — FY2024 Form 10-K',
          snippet:
            'Consolidated revenue totaled $2,500.4 million, reflecting 15.1% YoY top-line growth. Cloud infrastructure services contributed $1,420 million of aggregate revenues.',
          verified: true,
          confidenceScore: 99.4,
          auditRef: 'SEC_EDGAR_VERIFIED_P42',
          highlightedMetrics: [
            { label: 'FY2024 Revenue', value: '$2.50B' },
            { label: 'YoY Growth', value: '+15.1%' },
            { label: 'Cloud Segment', value: '$1.42B (+28.4%)' }
          ]
        };
        metricsData = [
          { label: 'Cloud Services', fy23: '$1,106M', fy24: '$1,420M', change: '+28.4%', trend: 'up' as const },
          { label: 'Enterprise Software', fy23: '$734M', fy24: '$780M', change: '+6.3%', trend: 'up' as const },
          { label: 'Advisory & Operations', fy23: '$332M', fy24: '$300M', change: '-9.6%', trend: 'down' as const }
        ];
      } else {
        responseText = `Based on the audited filings in **${activeDoc.name}**, operational metrics demonstrate disciplined capital allocation and sustained top-line execution. Guidance indicates high customer lifetime value with negative net churn.`;
        citationData = {
          documentId: activeDoc.id,
          documentName: activeDoc.name,
          page: 42,
          sectionTitle: 'Management Discussion & Analysis — Segment Overview',
          snippet: `Operating results extracted from ${activeDoc.name} confirm verified compliance with GAAP standards as examined in Section 7.`,
          verified: true,
          confidenceScore: 97.8,
          auditRef: 'SEC_AUDIT_INDEX_P42'
        };
      }

      const aiMsg: ChatMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: responseText,
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        citation: citationData,
        confidenceIndicator: {
          verified: true,
          label: 'Verified from source'
        },
        metrics: metricsData
      };

      setChatMessages((prev) => [...prev, aiMsg]);
      setIsStreaming(false);
    }, 450);
  };

  const handleResetChat = () => {
    setChatMessages(INITIAL_CHAT_MESSAGES);
  };

  const handleAddDocument = (newDoc: FinancialDocument) => {
    setDocuments((prev) => [newDoc, ...prev]);
    setSelectedDocId(newDoc.id);
  };

  // The core application content (Header + Sidebar + ChatPanel)
  const appWorkspaceContent = (
    <div className="flex-1 flex flex-col h-full min-h-0 overflow-hidden">
      <Header
        accent={accent}
        setAccent={setAccent}
        theme={theme}
        setTheme={setTheme}
        viewMode={viewMode}
        setViewMode={setViewMode}
        onOpenUpload={() => setIsUploadOpen(true)}
        activeDocName={activeDoc.name}
      />

      <div className="flex-1 flex min-h-0 overflow-hidden">
        {/* Left Sidebar showing uploaded financial documents */}
        <Sidebar
          documents={documents}
          selectedDocId={selectedDocId}
          onSelectDoc={(id) => setSelectedDocId(id)}
          onOpenUpload={() => setIsUploadOpen(true)}
          accent={accent}
          theme={theme}
        />

        {/* Main Center Panel is the Chat Interface */}
        <ChatPanel
          messages={chatMessages}
          onSendMessage={handleSendMessage}
          onSelectCitation={(citation) => setActiveCitation(citation)}
          onResetChat={handleResetChat}
          accent={accent}
          theme={theme}
          activeDoc={activeDoc}
          isStreaming={isStreaming}
        />
      </div>
    </div>
  );

  return (
    <div
      className={`w-screen h-screen flex flex-col overflow-hidden transition-colors duration-200 ${
        theme === 'dark-navy' ? 'bg-[#070C18] text-slate-100' : 'bg-slate-50 text-slate-900'
      }`}
    >
      {viewMode === 'live' ? (
        appWorkspaceContent
      ) : (
        <div className="flex-1 flex flex-col h-full min-h-0 overflow-hidden">
          {/* Top Bar even in 16:9 mockup mode for switching */}
          <Header
            accent={accent}
            setAccent={setAccent}
            theme={theme}
            setTheme={setTheme}
            viewMode={viewMode}
            setViewMode={setViewMode}
            onOpenUpload={() => setIsUploadOpen(true)}
            activeDocName={activeDoc.name}
          />
          <MockupPresentationView
            accent={accent}
            theme={theme}
            mockupImagePath={mockupImage}
          >
            {appWorkspaceContent}
          </MockupPresentationView>
        </div>
      )}

      {/* Citation Inspector Drawer / Modal */}
      <CitationDrawer
        citation={activeCitation}
        onClose={() => setActiveCitation(null)}
        accent={accent}
        theme={theme}
      />

      {/* Upload Document Modal */}
      <UploadModal
        isOpen={isUploadOpen}
        onClose={() => setIsUploadOpen(false)}
        onAddDocument={handleAddDocument}
        accent={accent}
        theme={theme}
      />
    </div>
  );
}
