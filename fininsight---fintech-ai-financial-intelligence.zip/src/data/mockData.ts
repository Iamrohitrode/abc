import { FinancialDocument, ChatMessage, FinancialMetric } from '../types';

export const INITIAL_DOCUMENTS: FinancialDocument[] = [
  {
    id: 'doc-1',
    name: 'Company_Annual_Report_2024.pdf',
    size: '12.8 MB',
    pages: 148,
    uploadDate: 'Oct 02, 2024',
    status: 'indexed',
    type: 'Annual Report',
    description: 'Comprehensive Form 10-K containing consolidated statement of operations, balance sheet, and MD&A.',
    keyHighlights: ['FY2024 Total Revenue: $2.50B (+15% YoY)', 'Cloud ARR: $1.42B (+28.4% YoY)', 'Operating Cash Flow: $640M']
  },
  {
    id: 'doc-2',
    name: 'Q3_Filing.pdf',
    size: '4.6 MB',
    pages: 52,
    uploadDate: 'Sep 18, 2024',
    status: 'indexed',
    type: 'Quarterly Filing',
    description: 'Form 10-Q report for fiscal third quarter ending September 30, with quarterly segment margins.',
    keyHighlights: ['Q3 Net Income: $184M (+18.2% YoY)', 'Gross Margin: 71.4%', 'Deferred Revenue: $890M']
  },
  {
    id: 'doc-3',
    name: '10K_Consolidated_Statement.pdf',
    size: '18.2 MB',
    pages: 210,
    uploadDate: 'Aug 24, 2024',
    status: 'indexed',
    type: 'Annual Report',
    description: 'Audited consolidated balance sheet, cash flows, and notes to financial statements with KPMG LLP report.',
    keyHighlights: ['Total Assets: $8.42B', 'Cash & Short-Term Equiv: $1.85B', 'Long-term Debt: $920M']
  },
  {
    id: 'doc-4',
    name: 'Q2_Earnings_Release.pdf',
    size: '3.1 MB',
    pages: 28,
    uploadDate: 'Jul 15, 2024',
    status: 'indexed',
    type: 'Earnings',
    description: 'Earnings press release and executive letter to shareholders detailing mid-year margin expansion.',
    keyHighlights: ['Operating Margin: 24.8% (+210 bps)', 'Free Cash Flow: $310M', 'Capex: $85M']
  },
  {
    id: 'doc-5',
    name: 'Investor_Presentation_FY24.pdf',
    size: '15.4 MB',
    pages: 46,
    uploadDate: 'Jun 28, 2024',
    status: 'indexed',
    type: 'Investor',
    description: 'Strategic roadmap presentation deck highlighting enterprise cloud TAM and customer retention (118% NRR).',
    keyHighlights: ['Net Retention Rate: 118%', 'Enterprise Clients >$100k ARR: 1,420', 'R&D Spend: 14.5%']
  }
];

export const INITIAL_CHAT_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-1',
    sender: 'user',
    text: 'What was the revenue growth in FY2024?',
    timestamp: '10:42 AM'
  },
  {
    id: 'msg-2',
    sender: 'assistant',
    text: 'Revenue for FY2024 was **$2.5 billion**, representing a **15% increase** compared to FY2023. This growth was primarily driven by **strong performance in the cloud services sector**.',
    timestamp: '10:42 AM',
    citation: {
      documentId: 'doc-1',
      documentName: 'Company_Annual_Report_2024.pdf',
      page: 42,
      sectionTitle: 'Management Discussion & Analysis — Consolidated Operational Results',
      snippet: 'Total consolidated revenue reached $2,500.4 million for the fiscal year ended December 31, 2024, an increase of 15.1% compared to $2,172.0 million in fiscal 2023. Growth was accelerated by enterprise migration to our Managed Cloud Infrastructure segment which expanded 28.4% year-over-year.',
      verified: true,
      confidenceScore: 99.4,
      auditRef: 'KPMG_AUDIT_SEC_ITEM_7_P42',
      highlightedMetrics: [
        { label: 'FY2024 Revenue', value: '$2,500.4M' },
        { label: 'FY2023 Revenue', value: '$2,172.0M' },
        { label: 'YoY Growth Rate', value: '+15.1%' },
        { label: 'Cloud Segment Contribution', value: '56.8% ($1,420M)' }
      ]
    },
    confidenceIndicator: {
      verified: true,
      label: 'Verified from source'
    },
    metrics: [
      { label: 'Cloud Services', fy23: '$1,106M', fy24: '$1,420M', change: '+28.4%', trend: 'up' },
      { label: 'Enterprise Software', fy23: '$734M', fy24: '$780M', change: '+6.3%', trend: 'up' },
      { label: 'Advisory & Operations', fy23: '$332M', fy24: '$300M', change: '-9.6%', trend: 'down' }
    ]
  }
];

export const SUGGESTED_QUERIES = [
  'What was the revenue growth in FY2024?',
  'What were the operating margins in Q3 2024?',
  'Summarize the primary risk factors in the 10-K',
  'What is the current net debt and liquidity position?',
  'How did Cloud ARR perform compared to FY2023?'
];

export const FINANCIAL_KNOWLEDGE_BASE: Record<string, {
  text: string;
  citation: NonNullable<ChatMessage['citation']>;
  metrics?: FinancialMetric[];
}> = {
  margin: {
    text: 'Operating margin for Q3 2024 expanded to **24.8%**, an increase of **210 basis points** year-over-year from 22.7% in Q3 2023. Margin gains were propelled by automation efficiencies in server infrastructure and reduced customer acquisition costs.',
    citation: {
      documentId: 'doc-2',
      documentName: 'Q3_Filing.pdf',
      page: 18,
      sectionTitle: 'Segment Operating Profitability & Operating Expenses',
      snippet: 'Operating income totaled $184.2 million representing an operating margin of 24.8%, compared to $146.8 million (22.7%) for the three months ended September 30, 2023.',
      verified: true,
      confidenceScore: 98.7,
      auditRef: 'SEC_FORM_10Q_Q3_P18',
      highlightedMetrics: [
        { label: 'Q3 Operating Income', value: '$184.2M' },
        { label: 'Operating Margin', value: '24.8%' },
        { label: 'YoY Margin Expansion', value: '+210 bps' }
      ]
    },
    metrics: [
      { label: 'Operating Income', fy23: '$146.8M', fy24: '$184.2M', change: '+25.5%', trend: 'up' },
      { label: 'Gross Margin', fy23: '69.1%', fy24: '71.4%', change: '+230 bps', trend: 'up' },
      { label: 'Operating Margin', fy23: '22.7%', fy24: '24.8%', change: '+210 bps', trend: 'up' }
    ]
  },
  risk: {
    text: 'In Item 1A of the 10-K, the primary risk factors identified are: **(1)** macroeconomic volatility impacting enterprise IT discretionary budgets; **(2)** international regulatory compliance for cross-border data sovereignty; and **(3)** supply-chain lead times for accelerated compute hardware.',
    citation: {
      documentId: 'doc-3',
      documentName: '10K_Consolidated_Statement.pdf',
      page: 14,
      sectionTitle: 'Item 1A. Risk Factors — Enterprise Exposure and Regulatory Scrutiny',
      snippet: 'Uncertain global economic conditions may cause prospective clients to delay enterprise subscription commitments or request elongated procurement cycles...',
      verified: true,
      confidenceScore: 99.1,
      auditRef: '10K_AUDITED_ITEM1A_P14',
      highlightedMetrics: [
        { label: 'Primary Risk Category', value: 'Enterprise IT Spending Deceleration' },
        { label: 'Regulatory Exposure', value: 'EU Data Protection & Sovereign Clouds' },
        { label: 'Hardware Supply Cycle', value: '24-32 week GPU lead times' }
      ]
    }
  },
  liquidity: {
    text: 'As of the latest filing, total cash and short-term liquid investments stood at **$1.85 billion**, with total long-term debt of **$920 million**. This provides a net cash position of **+$930 million** and a conservative net debt-to-EBITDA ratio of -0.8x.',
    citation: {
      documentId: 'doc-3',
      documentName: '10K_Consolidated_Statement.pdf',
      page: 58,
      sectionTitle: 'Consolidated Balance Sheets — Cash & Debt Obligations',
      snippet: 'Cash and cash equivalents totaled $1,240.5 million and marketable securities totaled $609.5 million as of December 31, 2024. Senior notes maturing 2029 comprise $920.0 million.',
      verified: true,
      confidenceScore: 99.8,
      auditRef: '10K_AUDITED_BALANCE_SHEET_P58',
      highlightedMetrics: [
        { label: 'Cash & Short-Term Inv.', value: '$1,850.0M' },
        { label: 'Long-term Debt', value: '$920.0M' },
        { label: 'Net Cash Position', value: '+$930.0M' }
      ]
    },
    metrics: [
      { label: 'Cash Equivalents', fy23: '$1,520M', fy24: '$1,850M', change: '+21.7%', trend: 'up' },
      { label: 'Senior Notes Debt', fy23: '$950M', fy24: '$920M', change: '-3.2%', trend: 'down' },
      { label: 'Net Cash', fy23: '$570M', fy24: '$930M', change: '+63.2%', trend: 'up' }
    ]
  },
  cloud: {
    text: 'Cloud Annual Recurring Revenue (ARR) reached **$1.42 billion** in FY2024, climbing **+28.4% YoY**. Net Revenue Retention (NRR) in cloud enterprise accounts stood at **118%**, reflecting strong multi-product adoption.',
    citation: {
      documentId: 'doc-5',
      documentName: 'Investor_Presentation_FY24.pdf',
      page: 12,
      sectionTitle: 'Cloud ARR Growth Trajectory & Cohort Expansion',
      snippet: 'Cloud segment ARR exceeded $1,420M milestone with 118% net dollar expansion. 68% of Fortune 500 customers utilize 3+ platform modules.',
      verified: true,
      confidenceScore: 99.2,
      auditRef: 'INVESTOR_DECK_SLIDE_12',
      highlightedMetrics: [
        { label: 'Cloud ARR', value: '$1.42B' },
        { label: 'YoY ARR Expansion', value: '+28.4%' },
        { label: 'Net Retention Rate', value: '118%' }
      ]
    },
    metrics: [
      { label: 'Cloud ARR', fy23: '$1.11B', fy24: '$1.42B', change: '+28.4%', trend: 'up' },
      { label: 'Net Dollar Retention', fy23: '115%', fy24: '118%', change: '+300 bps', trend: 'up' },
      { label: 'Enterprise Accounts (>100k)', fy23: '1,180', fy24: '1,420', change: '+20.3%', trend: 'up' }
    ]
  }
};
