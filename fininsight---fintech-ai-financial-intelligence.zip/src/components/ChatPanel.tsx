import React, { useState, useRef, useEffect } from 'react';
import { ChatMessage, CitationInfo, AccentColor, ColorTheme, FinancialDocument } from '../types';
import { Send, CheckCircle2, FileText, Sparkles, ArrowRight, CornerDownLeft, RefreshCw, BarChart3, ChevronDown, ChevronUp, Copy, Check } from 'lucide-react';
import { SUGGESTED_QUERIES, FINANCIAL_KNOWLEDGE_BASE } from '../data/mockData';
import { FinLogo } from './FinLogo';

interface ChatPanelProps {
  messages: ChatMessage[];
  onSendMessage: (text: string) => void;
  onSelectCitation: (citation: CitationInfo) => void;
  onResetChat: () => void;
  accent: AccentColor;
  theme: ColorTheme;
  activeDoc: FinancialDocument;
  isStreaming?: boolean;
}

export const ChatPanel: React.FC<ChatPanelProps> = ({
  messages,
  onSendMessage,
  onSelectCitation,
  onResetChat,
  accent,
  theme,
  activeDoc,
  isStreaming = false
}) => {
  const [inputText, setInputText] = useState('');
  const [copiedMsgId, setCopiedMsgId] = useState<string | null>(null);
  const [expandedMetrics, setExpandedMetrics] = useState<Record<string, boolean>>({ 'msg-2': true });
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const isDark = theme === 'dark-navy';
  const isEmerald = accent === 'emerald';

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isStreaming]);

  const handleSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText);
    setInputText('');
  };

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedMsgId(id);
    setTimeout(() => setCopiedMsgId(null), 2000);
  };

  const toggleMetrics = (msgId: string) => {
    setExpandedMetrics((prev) => ({
      ...prev,
      [msgId]: !prev[msgId]
    }));
  };

  return (
    <main
      className={`flex-1 flex flex-col h-full min-w-0 transition-colors duration-200 relative ${
        isDark ? 'bg-[#070C18] text-slate-100' : 'bg-[#FAFCFF] text-slate-800'
      }`}
    >
      {/* Top Context Subheader */}
      <div
        className={`px-4 sm:px-6 py-2.5 border-b flex items-center justify-between text-xs transition-colors shrink-0 ${
          isDark ? 'border-[#1C2638] bg-[#0A1020]' : 'border-slate-200 bg-white'
        }`}
      >
        <div className="flex items-center gap-2 truncate">
          <span className="text-slate-400">Context:</span>
          <span className="inline-flex items-center gap-1.5 font-medium px-2 py-0.5 rounded bg-slate-500/10 text-slate-300 truncate">
            <FileText className="w-3.5 h-3.5 text-red-400 shrink-0" />
            <span className="truncate">{activeDoc.name}</span>
          </span>
          <span className="hidden sm:inline text-slate-500">({activeDoc.pages} pages indexed)</span>
        </div>

        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onResetChat}
            className={`flex items-center gap-1 text-[11px] text-slate-400 hover:text-slate-200 transition-colors`}
            title="Reset to default conversation"
          >
            <RefreshCw className="w-3 h-3" />
            <span className="hidden sm:inline">Reset</span>
          </button>
        </div>
      </div>

      {/* Chat Messages Container */}
      <div className="flex-1 overflow-y-auto px-4 sm:px-8 lg:px-12 py-6 space-y-6">
        {messages.map((message) => {
          const isUser = message.sender === 'user';

          if (isUser) {
            return (
              <div key={message.id} className="flex justify-end items-start group">
                <div className="max-w-xl flex flex-col items-end">
                  {/* User question bubble on the right */}
                  <div
                    className={`px-4 py-3 rounded-2xl rounded-tr-xs text-sm sm:text-base font-medium shadow-sm transition-all ${
                      isDark
                        ? 'bg-[#15243C] text-slate-100 border border-[#223554]'
                        : 'bg-slate-900 text-white'
                    }`}
                  >
                    <p className="leading-relaxed">{message.text}</p>
                  </div>
                  <span className="text-[10px] font-mono text-slate-400 mt-1 px-1">
                    {message.timestamp}
                  </span>
                </div>
              </div>
            );
          }

          // AI Response Bubble on the left
          return (
            <div key={message.id} className="flex items-start gap-3 sm:gap-4 max-w-3xl">
              {/* AI Avatar */}
              <div className="shrink-0 mt-1">
                <div
                  className={`w-8 h-8 rounded-lg flex items-center justify-center border shadow-xs ${
                    isDark
                      ? 'bg-[#0E1A30] border-[#1E2E4E]'
                      : 'bg-white border-slate-200'
                  }`}
                >
                  <FinLogo accent={accent} size={20} />
                </div>
              </div>

              {/* AI Message Content */}
              <div className="flex-1 min-w-0 space-y-2.5">
                {/* Main Text Card */}
                <div
                  className={`p-4 sm:p-5 rounded-2xl rounded-tl-xs border transition-all text-sm sm:text-base leading-relaxed ${
                    isDark
                      ? 'bg-[#0E1628] border-[#1C283F] text-slate-200 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-800 shadow-xs'
                  }`}
                >
                  <div className="prose prose-sm prose-invert max-w-none">
                    <p
                      dangerouslySetInnerHTML={{
                        __html: message.text.replace(/\*\*(.*?)\*\*/g, '<strong class="font-semibold text-white">$1</strong>')
                      }}
                    />
                  </div>

                  {/* Optional Financial Breakdown Table */}
                  {message.metrics && message.metrics.length > 0 && (
                    <div className="mt-3.5 pt-3 border-t border-slate-700/30">
                      <button
                        onClick={() => toggleMetrics(message.id)}
                        className="flex items-center justify-between w-full text-xs text-slate-400 hover:text-slate-200 transition-colors py-1"
                      >
                        <span className="flex items-center gap-1.5 font-medium">
                          <BarChart3 className={`w-3.5 h-3.5 ${isEmerald ? 'text-emerald-400' : 'text-sky-400'}`} />
                          Segment Breakdown (FY23 vs FY24)
                        </span>
                        {expandedMetrics[message.id] ? (
                          <ChevronUp className="w-3.5 h-3.5" />
                        ) : (
                          <ChevronDown className="w-3.5 h-3.5" />
                        )}
                      </button>

                      {expandedMetrics[message.id] && (
                        <div
                          className={`mt-2 rounded-lg border overflow-hidden ${
                            isDark ? 'bg-[#090F1E] border-[#1B273D]' : 'bg-slate-50 border-slate-200'
                          }`}
                        >
                          <table className="w-full text-left text-xs">
                            <thead className={`border-b text-[11px] text-slate-400 font-medium ${isDark ? 'border-[#1B273D] bg-[#0C1426]' : 'border-slate-200 bg-slate-100/60'}`}>
                              <tr>
                                <th className="py-1.5 px-3">Segment</th>
                                <th className="py-1.5 px-3 text-right">FY2023</th>
                                <th className="py-1.5 px-3 text-right">FY2024</th>
                                <th className="py-1.5 px-3 text-right">Variance</th>
                              </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800/40 text-slate-300">
                              {message.metrics.map((m, idx) => (
                                <tr key={idx} className="hover:bg-slate-800/20">
                                  <td className="py-1.5 px-3 font-medium text-slate-200">{m.label}</td>
                                  <td className="py-1.5 px-3 text-right font-mono tabular-nums text-slate-400">{m.fy23}</td>
                                  <td className="py-1.5 px-3 text-right font-mono tabular-nums text-slate-100">{m.fy24}</td>
                                  <td
                                    className={`py-1.5 px-3 text-right font-mono tabular-nums font-medium ${
                                      m.trend === 'up' ? 'text-emerald-400' : 'text-red-400'
                                    }`}
                                  >
                                    {m.change}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Actions footer (copy, timestamp) */}
                  <div className="flex items-center justify-between pt-2.5 mt-2 text-[11px] text-slate-400">
                    <span className="font-mono">{message.timestamp}</span>
                    <button
                      onClick={() => handleCopy(message.id, message.text)}
                      className="flex items-center gap-1 hover:text-slate-200 transition-colors"
                      title="Copy response"
                    >
                      {copiedMsgId === message.id ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400" />
                          <span className="text-emerald-400">Copied</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>Copy</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>

                {/* Below response: Citation Tag in subtle pill-shaped badge & Confidence Indicator */}
                <div className="flex flex-wrap items-center gap-2.5 pt-0.5">
                  {message.citation && (
                    <button
                      onClick={() => onSelectCitation(message.citation!)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-medium border transition-all cursor-pointer shadow-2xs group ${
                        isDark
                          ? 'bg-[#101B2E] border-[#22334F] text-slate-300 hover:border-slate-400 hover:text-white'
                          : 'bg-white border-slate-300 text-slate-700 hover:border-slate-500 hover:text-slate-900'
                      }`}
                      title="Click to inspect source filing on Page 42"
                    >
                      <FileText className="w-3 h-3 text-red-400 shrink-0" />
                      <span>
                        Source: Annual Report 2024, Page {message.citation.page}
                      </span>
                      <ArrowRight className="w-3 h-3 opacity-60 group-hover:opacity-100 group-hover:translate-x-0.5 transition-transform" />
                    </button>
                  )}

                  {/* Subtle confidence indicator: small green checkmark icon labeled 'Verified from source' */}
                  {message.confidenceIndicator && (
                    <div className="inline-flex items-center gap-1 text-xs font-medium text-emerald-500 select-none">
                      <CheckCircle2 className="w-3.5 h-3.5 fill-emerald-500/10 text-emerald-500" />
                      <span className="text-[11px] tracking-tight">{message.confidenceIndicator.label}</span>
                    </div>
                  )}
                </div>
              </div>
            </div>
          );
        })}

        {/* Loading / Streaming State */}
        {isStreaming && (
          <div className="flex items-start gap-3 sm:gap-4 max-w-xl animate-pulse">
            <div className="w-8 h-8 rounded-lg bg-[#0E1A30] border border-[#1E2E4E] flex items-center justify-center shrink-0">
              <FinLogo accent={accent} size={20} />
            </div>
            <div className="p-4 rounded-2xl rounded-tl-xs bg-[#0E1628] border border-[#1C283F] text-slate-400 text-xs flex items-center gap-2">
              <RefreshCw className="w-3.5 h-3.5 animate-spin text-emerald-400" />
              <span>Cross-verifying GAAP tables and footnote disclosures...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      <div className={`px-4 sm:px-8 lg:px-12 py-2 border-t flex items-center gap-2 overflow-x-auto select-none ${isDark ? 'border-[#1C2638] bg-[#080E1C]' : 'border-slate-100 bg-slate-50/50'}`}>
        <span className="text-[10px] font-semibold uppercase tracking-wider text-slate-500 shrink-0">
          Suggested:
        </span>
        <div className="flex items-center gap-1.5 flex-nowrap">
          {SUGGESTED_QUERIES.map((query, idx) => (
            <button
              key={idx}
              onClick={() => onSendMessage(query)}
              className={`text-xs px-2.5 py-1 rounded-md border whitespace-nowrap transition-colors shrink-0 ${
                isDark
                  ? 'bg-[#0E172B] border-[#1C273D] text-slate-300 hover:text-white hover:border-slate-500'
                  : 'bg-white border-slate-200 text-slate-700 hover:text-slate-900 hover:border-slate-400 shadow-2xs'
              }`}
            >
              {query}
            </button>
          ))}
        </div>
      </div>

      {/* Bottom Chat Input Box */}
      <div
        className={`p-4 sm:p-5 border-t shrink-0 transition-colors ${
          isDark ? 'border-[#1C2638] bg-[#0A1020]' : 'border-slate-200 bg-white'
        }`}
      >
        <form onSubmit={handleSubmit} className="max-w-4xl mx-auto relative flex items-center">
          <input
            ref={inputRef}
            type="text"
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="Ask a question about Annual Report 2024 or Q3 Filing..."
            className={`w-full pl-4 pr-12 py-3 rounded-xl border text-sm sm:text-base transition-all focus:outline-none ${
              isDark
                ? isEmerald
                  ? 'bg-[#0E172B] border-[#223554] text-slate-100 placeholder-slate-500 focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500/30'
                  : 'bg-[#0E172B] border-[#223554] text-slate-100 placeholder-slate-500 focus:border-sky-500 focus:ring-1 focus:ring-sky-500/30'
                : 'bg-white border-slate-300 text-slate-900 placeholder-slate-400 focus:border-slate-500 focus:ring-1 focus:ring-slate-300 shadow-xs'
            }`}
          />

          {/* Send Button */}
          <button
            type="submit"
            disabled={!inputText.trim()}
            className={`absolute right-2 p-2 rounded-lg transition-all ${
              inputText.trim()
                ? isEmerald
                  ? 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs cursor-pointer'
                  : 'bg-sky-600 hover:bg-sky-500 text-white shadow-xs cursor-pointer'
                : isDark
                ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
                : 'bg-slate-200 text-slate-400 cursor-not-allowed'
            }`}
            title="Send query"
          >
            <Send className="w-4 h-4" />
          </button>
        </form>

        <div className="flex items-center justify-between max-w-4xl mx-auto mt-2 text-[10px] text-slate-400 px-1">
          <span className="flex items-center gap-1">
            <CheckCircle2 className="w-3 h-3 text-emerald-500" />
            <span>Deterministic financial fact verification active</span>
          </span>
          <span className="hidden sm:inline font-mono">Press Return ↵ to submit</span>
        </div>
      </div>
    </main>
  );
};
