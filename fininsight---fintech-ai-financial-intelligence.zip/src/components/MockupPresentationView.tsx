import React, { useState } from 'react';
import { AccentColor, ColorTheme } from '../types';
import { Maximize2, Minimize2, ZoomIn, ZoomOut, Image as ImageIcon, Sparkles, Layers } from 'lucide-react';

interface MockupPresentationViewProps {
  children: React.ReactNode;
  accent: AccentColor;
  theme: ColorTheme;
  mockupImagePath?: string;
}

export const MockupPresentationView: React.FC<MockupPresentationViewProps> = ({
  children,
  accent,
  theme,
  mockupImagePath
}) => {
  const [scale, setScale] = useState<number>(100);
  const [viewTab, setViewTab] = useState<'interactive' | 'asset' | 'split'>('interactive');

  const isDark = theme === 'dark-navy';
  const isEmerald = accent === 'emerald';

  return (
    <div className={`flex-1 flex flex-col h-full overflow-hidden p-3 sm:p-6 select-none ${
      isDark ? 'bg-[#040812]' : 'bg-[#EDF2F7]'
    }`}>
      {/* Mockup Canvas Bar */}
      <div className="flex items-center justify-between mb-3 px-2 text-xs text-slate-400">
        <div className="flex items-center gap-3">
          <span className="font-semibold text-slate-200 flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${isEmerald ? 'bg-emerald-400' : 'bg-sky-400'}`} />
            FinInsight 16:9 UI/UX Mockup Canvas
          </span>
          <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
            1920 × 1080 (16:9 AR)
          </span>
        </div>

        {/* View Toggle Tabs */}
        <div className="flex items-center gap-2">
          {mockupImagePath && (
            <div className="flex items-center p-0.5 rounded-lg bg-slate-800 border border-slate-700/60 text-[11px]">
              <button
                onClick={() => setViewTab('interactive')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  viewTab === 'interactive' ? 'bg-slate-700 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Interactive UI
              </button>
              <button
                onClick={() => setViewTab('split')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  viewTab === 'split' ? 'bg-slate-700 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Side-by-Side
              </button>
              <button
                onClick={() => setViewTab('asset')}
                className={`px-2.5 py-1 rounded transition-colors ${
                  viewTab === 'asset' ? 'bg-slate-700 text-white font-medium' : 'text-slate-400 hover:text-white'
                }`}
              >
                Rendered Mockup Art
              </button>
            </div>
          )}

          {/* Zoom controls */}
          <div className="hidden sm:flex items-center gap-1 bg-slate-800/80 rounded-lg p-0.5 border border-slate-700/60">
            <button
              onClick={() => setScale((s) => Math.max(75, s - 10))}
              className="p-1 text-slate-400 hover:text-white"
              title="Zoom out"
            >
              <ZoomOut className="w-3.5 h-3.5" />
            </button>
            <span className="font-mono text-[10px] text-slate-300 px-1">{scale}%</span>
            <button
              onClick={() => setScale((s) => Math.min(120, s + 10))}
              className="p-1 text-slate-400 hover:text-white"
              title="Zoom in"
            >
              <ZoomIn className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Presentation Stage */}
      <div className="flex-1 flex items-center justify-center overflow-auto p-2">
        {viewTab === 'interactive' && (
          <div
            style={{ transform: `scale(${scale / 100})`, transformOrigin: 'center center' }}
            className="w-full max-w-[1280px] aspect-[16/9] rounded-2xl shadow-2xl border overflow-hidden flex flex-col transition-all duration-200 border-[#1C283F] bg-[#070C18]"
          >
            {/* Window Chrome / Title Bar */}
            <div className="h-9 px-4 border-b flex items-center justify-between shrink-0 bg-[#0A1020] border-[#1C2638]">
              <div className="flex items-center gap-2">
                <div className="w-2.5 h-2.5 rounded-full bg-rose-500/80" />
                <div className="w-2.5 h-2.5 rounded-full bg-amber-500/80" />
                <div className="w-2.5 h-2.5 rounded-full bg-emerald-500/80" />
              </div>
              <div className="text-[11px] font-mono text-slate-400 bg-slate-900/80 px-3 py-0.5 rounded border border-slate-800">
                fininsight.app/workspace/annual-report-2024
              </div>
              <div className="w-12" />
            </div>

            {/* Embedded Interactive Application */}
            <div className="flex-1 min-h-0 flex overflow-hidden">
              {children}
            </div>
          </div>
        )}

        {viewTab === 'asset' && mockupImagePath && (
          <div
            style={{ transform: `scale(${scale / 100})`, transformOrigin: 'center center' }}
            className="w-full max-w-[1280px] aspect-[16/9] rounded-2xl shadow-2xl border overflow-hidden transition-all duration-200 border-[#1C283F] bg-black flex items-center justify-center relative"
          >
            <img
              src={mockupImagePath}
              alt="FinInsight 16:9 UI Mockup"
              referrerPolicy="no-referrer"
              className="w-full h-full object-contain"
            />
          </div>
        )}

        {viewTab === 'split' && mockupImagePath && (
          <div className="w-full h-full grid grid-cols-1 lg:grid-cols-2 gap-4 max-w-[1400px]">
            {/* Left: Interactive */}
            <div className="flex flex-col h-full rounded-xl border border-[#1C283F] overflow-hidden bg-[#070C18] shadow-xl">
              <div className="p-2 border-b border-[#1C283F] bg-[#0A1020] text-xs font-semibold text-slate-200 flex items-center justify-between">
                <span>Interactive Live Mockup</span>
                <span className="text-[10px] font-mono text-emerald-400">Ready</span>
              </div>
              <div className="flex-1 min-h-0 flex overflow-hidden">
                {children}
              </div>
            </div>

            {/* Right: Rendered Asset */}
            <div className="flex flex-col h-full rounded-xl border border-[#1C283F] overflow-hidden bg-black shadow-xl">
              <div className="p-2 border-b border-[#1C283F] bg-[#0A1020] text-xs font-semibold text-slate-200 flex items-center justify-between">
                <span>16:9 Visual Mockup Blueprint</span>
                <span className="text-[10px] font-mono text-slate-400">Original Concept</span>
              </div>
              <div className="flex-1 flex items-center justify-center p-2 bg-slate-950">
                <img
                  src={mockupImagePath}
                  alt="FinInsight Mockup Asset"
                  referrerPolicy="no-referrer"
                  className="max-h-full max-w-full object-contain rounded-lg shadow-md"
                />
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
