import React, { useState } from 'react';
import { FinancialDocument, AccentColor, ColorTheme } from '../types';
import { X, UploadCloud, FileText, CheckCircle2, ArrowRight } from 'lucide-react';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAddDocument: (doc: FinancialDocument) => void;
  accent: AccentColor;
  theme: ColorTheme;
}

export const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  onAddDocument,
  accent,
  theme
}) => {
  const [docName, setDocName] = useState('Q4_Earnings_Report_2024.pdf');
  const [docType, setDocType] = useState<FinancialDocument['type']>('Quarterly Filing');
  const [isSimulating, setIsSimulating] = useState(false);

  if (!isOpen) return null;

  const isDark = theme === 'dark-navy';
  const isEmerald = accent === 'emerald';

  const handleUpload = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSimulating(true);

    setTimeout(() => {
      const newDoc: FinancialDocument = {
        id: `doc-${Date.now()}`,
        name: docName.endsWith('.pdf') ? docName : `${docName}.pdf`,
        size: '6.4 MB',
        pages: 68,
        uploadDate: 'Just now',
        status: 'indexed',
        type: docType,
        description: 'Uploaded SEC financial filing with consolidated statements and disclosures.',
        keyHighlights: ['Automated SEC EDGAR parsing complete', 'OCR table structures verified']
      };
      onAddDocument(newDoc);
      setIsSimulating(false);
      onClose();
    }, 600);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className={`w-full max-w-lg rounded-2xl shadow-2xl border p-6 transition-all ${
          isDark
            ? 'bg-[#0A1020] border-[#1E2E48] text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        <div className="flex items-center justify-between pb-4 border-b border-slate-700/30">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center">
              <FileText className="w-4 h-4 text-red-500" />
            </div>
            <div>
              <h3 className="text-sm font-semibold">Upload Financial Document</h3>
              <p className="text-xs text-slate-400">PDF, 10-K, 10-Q, 8-K, or Earnings Release</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleUpload} className="mt-4 space-y-4">
          {/* Dropzone mock */}
          <div
            className={`border-2 border-dashed rounded-xl p-6 text-center transition-all ${
              isDark
                ? 'border-slate-700 bg-[#070D1C] hover:border-slate-500'
                : 'border-slate-300 bg-slate-50 hover:border-slate-400'
            }`}
          >
            <UploadCloud className={`w-8 h-8 mx-auto mb-2 ${isEmerald ? 'text-emerald-400' : 'text-sky-400'}`} />
            <p className="text-xs font-medium text-slate-200">
              Drag & drop financial PDF, or browse computer
            </p>
            <p className="text-[11px] text-slate-400 mt-1">
              Supports audited statements up to 250 MB
            </p>
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">
              Document Name
            </label>
            <input
              type="text"
              value={docName}
              onChange={(e) => setDocName(e.target.value)}
              className={`w-full px-3 py-2 text-xs rounded-lg border focus:outline-none ${
                isDark
                  ? 'bg-[#060B17] border-slate-700 text-white focus:border-slate-500'
                  : 'bg-white border-slate-300 text-slate-900 focus:border-slate-500'
              }`}
              required
            />
          </div>

          <div>
            <label className="block text-xs font-medium text-slate-400 mb-1">
              Filing Classification
            </label>
            <select
              value={docType}
              onChange={(e) => setDocType(e.target.value as FinancialDocument['type'])}
              className={`w-full px-3 py-2 text-xs rounded-lg border focus:outline-none ${
                isDark
                  ? 'bg-[#060B17] border-slate-700 text-white focus:border-slate-500'
                  : 'bg-white border-slate-300 text-slate-900 focus:border-slate-500'
              }`}
            >
              <option value="Annual Report">Annual Report (Form 10-K)</option>
              <option value="Quarterly Filing">Quarterly Filing (Form 10-Q)</option>
              <option value="Earnings">Earnings Release</option>
              <option value="Investor">Investor Presentation</option>
              <option value="Audit">Audited Balance Sheet</option>
            </select>
          </div>

          <div className="pt-2 flex items-center justify-end gap-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 text-xs rounded-lg border border-slate-700 text-slate-300 hover:text-white"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={isSimulating}
              className={`px-4 py-2 text-xs font-semibold rounded-lg text-white transition-all flex items-center gap-1.5 ${
                isEmerald ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-sky-600 hover:bg-sky-500'
              }`}
            >
              {isSimulating ? (
                <span>Indexing Pages...</span>
              ) : (
                <>
                  <span>Index & Attach</span>
                  <ArrowRight className="w-3.5 h-3.5" />
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
