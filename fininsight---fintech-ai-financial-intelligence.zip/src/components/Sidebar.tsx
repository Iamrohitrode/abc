import React, { useState } from 'react';
import { FinancialDocument, AccentColor, ColorTheme } from '../types';
import { Search, Plus, FileText, CheckCircle2, ChevronRight, Layers, Database } from 'lucide-react';

interface SidebarProps {
  documents: FinancialDocument[];
  selectedDocId: string;
  onSelectDoc: (id: string) => void;
  onOpenUpload: () => void;
  accent: AccentColor;
  theme: ColorTheme;
  isCollapsed?: boolean;
  onToggleCollapse?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  documents,
  selectedDocId,
  onSelectDoc,
  onOpenUpload,
  accent,
  theme,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterType, setFilterType] = useState<string>('all');

  const isDark = theme === 'dark-navy';
  const isEmerald = accent === 'emerald';

  const filteredDocs = documents.filter((doc) => {
    const matchesSearch = doc.name.toLowerCase().includes(searchQuery.toLowerCase());
    if (filterType === 'all') return matchesSearch;
    if (filterType === 'annual') return matchesSearch && doc.type === 'Annual Report';
    if (filterType === 'quarterly') return matchesSearch && doc.type === 'Quarterly Filing';
    return matchesSearch;
  });

  return (
    <aside
      className={`w-72 sm:w-80 border-r flex flex-col shrink-0 transition-colors duration-200 select-none ${
        isDark
          ? 'bg-[#0B132B] border-[#1C2638] text-slate-200'
          : 'bg-[#F8FAFC] border-slate-200 text-slate-800'
      }`}
    >
      {/* Sidebar Header & Document Title */}
      <div className={`p-3.5 border-b ${isDark ? 'border-[#1C2638]' : 'border-slate-200'}`}>
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <Layers className={`w-4 h-4 ${isEmerald ? 'text-emerald-400' : 'text-sky-400'}`} />
            <h2 className="text-xs font-semibold uppercase tracking-wider text-slate-400">
              Financial Documents
            </h2>
          </div>
          <span
            className={`text-[11px] font-mono px-2 py-0.5 rounded ${
              isDark ? 'bg-slate-800/80 text-slate-400' : 'bg-slate-200 text-slate-600'
            }`}
          >
            {documents.length} Files
          </span>
        </div>

        {/* Quick Search */}
        <div className="relative">
          <Search className="w-3.5 h-3.5 absolute left-2.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search filings, 10-K, 10-Q..."
            className={`w-full pl-8 pr-3 py-1.5 text-xs rounded-md border transition-all focus:outline-none ${
              isDark
                ? 'bg-[#070D1F] border-[#1C2638] text-slate-200 placeholder-slate-500 focus:border-slate-500'
                : 'bg-white border-slate-200 text-slate-900 placeholder-slate-400 focus:border-slate-400 shadow-2xs'
            }`}
          />
        </div>

        {/* Category Filters */}
        <div className="flex items-center gap-1 mt-2.5">
          {[
            { id: 'all', label: 'All Docs' },
            { id: 'annual', label: 'Annual Reports' },
            { id: 'quarterly', label: 'Quarterly' }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilterType(tab.id)}
              className={`px-2 py-1 text-[11px] rounded transition-colors ${
                filterType === tab.id
                  ? isDark
                    ? 'bg-[#1C2638] text-white font-medium'
                    : 'bg-white text-slate-900 font-medium shadow-2xs'
                  : isDark
                  ? 'text-slate-400 hover:text-slate-200'
                  : 'text-slate-500 hover:text-slate-800'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>
      </div>

      {/* Document List */}
      <div className="flex-1 overflow-y-auto p-2.5 space-y-1.5">
        {filteredDocs.map((doc) => {
          const isSelected = doc.id === selectedDocId;

          return (
            <button
              key={doc.id}
              onClick={() => onSelectDoc(doc.id)}
              className={`w-full text-left p-2.5 rounded-lg border transition-all group flex items-start gap-2.5 relative ${
                isSelected
                  ? isDark
                    ? isEmerald
                      ? 'bg-[#132238] border-emerald-500/40 shadow-sm'
                      : 'bg-[#132238] border-sky-500/40 shadow-sm'
                    : isEmerald
                    ? 'bg-emerald-50/50 border-emerald-500/30 shadow-2xs'
                    : 'bg-sky-50/50 border-sky-500/30 shadow-2xs'
                  : isDark
                  ? 'bg-[#0E172E]/60 border-transparent hover:bg-[#13203C] hover:border-[#1E2E4E]'
                  : 'bg-white border-slate-100 hover:border-slate-200 hover:bg-slate-50/80 shadow-2xs'
              }`}
            >
              {/* Small PDF Icon with Red Badge */}
              <div className="relative shrink-0 mt-0.5">
                <div className="w-7 h-8 rounded bg-red-500/10 border border-red-500/25 flex flex-col items-center justify-center p-0.5 shadow-2xs">
                  <FileText className="w-3.5 h-3.5 text-red-500" />
                  <span className="text-[7px] font-bold tracking-tighter text-red-600 uppercase font-mono mt-0.5">
                    PDF
                  </span>
                </div>
              </div>

              {/* Document details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-1">
                  <h3
                    className={`text-xs font-medium truncate ${
                      isSelected
                        ? isDark
                          ? 'text-white font-semibold'
                          : 'text-slate-900 font-semibold'
                        : isDark
                        ? 'text-slate-300 group-hover:text-white'
                        : 'text-slate-700 group-hover:text-slate-900'
                    }`}
                    title={doc.name}
                  >
                    {doc.name}
                  </h3>
                  {isSelected && (
                    <span
                      className={`w-1.5 h-1.5 rounded-full shrink-0 ${
                        isEmerald ? 'bg-emerald-400' : 'bg-sky-400'
                      }`}
                    />
                  )}
                </div>

                {/* Subtext info: Pages, Size, Status */}
                <div className="flex items-center gap-1.5 mt-1 text-[11px] text-slate-400">
                  <span className="font-mono tabular-nums">{doc.pages} pgs</span>
                  <span>·</span>
                  <span className="font-mono">{doc.size}</span>
                  <span>·</span>
                  <span className="flex items-center gap-0.5 text-emerald-500 font-medium">
                    <CheckCircle2 className="w-2.5 h-2.5" />
                    <span>Indexed</span>
                  </span>
                </div>
              </div>
            </button>
          );
        })}

        {filteredDocs.length === 0 && (
          <div className="p-6 text-center text-xs text-slate-400">
            No filings match "{searchQuery}"
          </div>
        )}
      </div>

      {/* Sidebar Footer with Indexing Status & Upload Action */}
      <div className={`p-3 border-t ${isDark ? 'border-[#1C2638] bg-[#080E1C]' : 'border-slate-200 bg-slate-50'}`}>
        <button
          onClick={onOpenUpload}
          className={`w-full py-2 px-3 rounded-lg text-xs font-medium border border-dashed flex items-center justify-center gap-2 transition-all ${
            isDark
              ? 'border-slate-700 text-slate-300 hover:border-slate-500 hover:bg-slate-800/60'
              : 'border-slate-300 text-slate-700 hover:border-slate-400 hover:bg-white shadow-2xs'
          }`}
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Upload Financial Report</span>
        </button>

        <div className="flex items-center justify-between text-[11px] text-slate-400 mt-2.5 pt-2 border-t border-slate-700/20">
          <div className="flex items-center gap-1.5">
            <Database className="w-3 h-3 text-slate-400" />
            <span>SEC Parser V2</span>
          </div>
          <span className="font-mono text-[10px]">484 pgs synced</span>
        </div>
      </div>
    </aside>
  );
};
