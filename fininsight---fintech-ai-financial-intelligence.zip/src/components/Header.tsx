import React from 'react';
import { FinLogo } from './FinLogo';
import { AccentColor, ColorTheme, ViewMode } from '../types';
import { Sparkles, Layout, Monitor, ShieldCheck, Sun, Moon } from 'lucide-react';

interface HeaderProps {
  accent: AccentColor;
  setAccent: (accent: AccentColor) => void;
  theme: ColorTheme;
  setTheme: (theme: ColorTheme) => void;
  viewMode: ViewMode;
  setViewMode: (mode: ViewMode) => void;
  onOpenUpload: () => void;
  activeDocName: string;
}

export const Header: React.FC<HeaderProps> = ({
  accent,
  setAccent,
  theme,
  setTheme,
  viewMode,
  setViewMode,
  onOpenUpload,
  activeDocName
}) => {
  const isDark = theme === 'dark-navy';
  const accentClass = accent === 'emerald' ? 'text-emerald-400' : 'text-sky-400';
  const accentBgClass = accent === 'emerald' ? 'bg-emerald-500' : 'bg-sky-500';

  return (
    <header
      className={`h-14 border-b flex items-center justify-between px-4 sm:px-6 select-none shrink-0 transition-colors duration-200 ${
        isDark
          ? 'bg-[#090E1A] border-[#1C2638] text-slate-100'
          : 'bg-white border-slate-200 text-slate-900 shadow-xs'
      }`}
    >
      {/* Zone 1: Brand title with magnifying glass over bar chart logo */}
      <div className="flex items-center gap-3 shrink-0">
        <FinLogo accent={accent} size={28} />
        <div className="flex items-center gap-2">
          <span className="font-semibold text-base sm:text-lg tracking-tight font-sans">
            Fin<span className={accentClass}>Insight</span>
          </span>
          <span
            className={`hidden md:inline-flex items-center text-[10px] font-mono px-1.5 py-0.5 rounded ${
              isDark ? 'bg-slate-800 text-slate-400 border border-slate-700/60' : 'bg-slate-100 text-slate-500 border border-slate-200'
            }`}
          >
            v2.4 SEC AI
          </span>
        </div>
      </div>

      {/* Zone 2: Navigation Links / View Switchers */}
      <nav className="flex items-center gap-1 sm:gap-2">
        {/* View Mode Switcher */}
        <div
          className={`flex items-center p-0.5 rounded-lg border ${
            isDark ? 'bg-[#0F172A] border-[#1E293B]' : 'bg-slate-100 border-slate-200'
          }`}
        >
          <button
            onClick={() => setViewMode('live')}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
              viewMode === 'live'
                ? isDark
                  ? 'bg-[#1E293B] text-white shadow-xs'
                  : 'bg-white text-slate-900 shadow-xs'
                : isDark
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="Interactive full-workspace view"
          >
            <Layout className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Workspace</span>
          </button>

          <button
            onClick={() => setViewMode('mockup-16x9')}
            className={`flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium rounded-md transition-all whitespace-nowrap ${
              viewMode === 'mockup-16x9'
                ? isDark
                  ? 'bg-[#1E293B] text-white shadow-xs'
                  : 'bg-white text-slate-900 shadow-xs'
                : isDark
                ? 'text-slate-400 hover:text-slate-200'
                : 'text-slate-600 hover:text-slate-900'
            }`}
            title="16:9 Presentation Mockup Frame"
          >
            <Monitor className="w-3.5 h-3.5" />
            <span>16:9 Mockup</span>
          </button>
        </div>

        {/* Accent Color Switcher: Emerald Green or Electric Blue */}
        <div
          className={`hidden lg:flex items-center gap-1 p-0.5 rounded-lg border ${
            isDark ? 'bg-[#0F172A] border-[#1E293B]' : 'bg-slate-100 border-slate-200'
          }`}
        >
          <button
            onClick={() => setAccent('emerald')}
            className={`flex items-center gap-1 px-2 py-1 text-xs rounded transition-all ${
              accent === 'emerald'
                ? isDark
                  ? 'bg-emerald-950/80 text-emerald-300 border border-emerald-700/50'
                  : 'bg-white text-emerald-700 shadow-xs font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Emerald Green Accent"
          >
            <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" />
            <span className="text-[11px]">Emerald</span>
          </button>
          <button
            onClick={() => setAccent('electric-blue')}
            className={`flex items-center gap-1 px-2 py-1 text-xs rounded transition-all ${
              accent === 'electric-blue'
                ? isDark
                  ? 'bg-sky-950/80 text-sky-300 border border-sky-700/50'
                : 'bg-white text-sky-700 shadow-xs font-medium'
                : 'text-slate-400 hover:text-slate-200'
            }`}
            title="Electric Blue Accent"
          >
            <span className="w-2 h-2 rounded-full bg-sky-500 inline-block" />
            <span className="text-[11px]">Electric</span>
          </button>
        </div>
      </nav>

      {/* Zone 3: Primary Action & Controls */}
      <div className="flex items-center gap-2 shrink-0">
        {/* Theme toggle: Dark navy vs light */}
        <button
          onClick={() => setTheme(isDark ? 'light' : 'dark-navy')}
          className={`p-1.5 rounded-lg border transition-colors ${
            isDark
              ? 'border-slate-800 text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
              : 'border-slate-200 text-slate-600 hover:text-slate-900 hover:bg-slate-100'
          }`}
          title={isDark ? 'Switch to Light Mode' : 'Switch to Dark Navy Mode'}
          aria-label="Toggle theme"
        >
          {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Upload document button */}
        <button
          onClick={onOpenUpload}
          className={`flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-lg text-white transition-all shadow-xs ${
            accent === 'emerald'
              ? 'bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700'
              : 'bg-sky-600 hover:bg-sky-500 active:bg-sky-700'
          }`}
        >
          <span>+ Upload PDF</span>
        </button>
      </div>
    </header>
  );
};
