import React from 'react';
import { AccentColor } from '../types';

interface FinLogoProps {
  accent: AccentColor;
  className?: string;
  size?: number;
}

export const FinLogo: React.FC<FinLogoProps> = ({ accent, className = '', size = 28 }) => {
  const accentHex = accent === 'emerald' ? '#10B981' : '#0284C7';
  const accentLight = accent === 'emerald' ? '#34D399' : '#38BDF8';

  return (
    <div className={`relative flex items-center justify-center shrink-0 ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 32 32"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="transition-transform duration-200 hover:scale-105"
      >
        {/* Background container badge */}
        <rect width="32" height="32" rx="7" fill="#0B132B" stroke="#1E293B" strokeWidth="1" />
        
        {/* Bar chart bars */}
        <rect x="7" y="18" width="3" height="6" rx="1" fill="#475569" />
        <rect x="12" y="14" width="3" height="10" rx="1" fill="#64748B" />
        <rect x="17" y="10" width="3" height="14" rx="1" fill={accentHex} />
        <rect x="22" y="7" width="3" height="17" rx="1" fill={accentLight} />

        {/* Magnifying glass positioned inspectingly over the rising bars */}
        <circle
          cx="17"
          cy="13"
          r="6.2"
          stroke={accentHex}
          strokeWidth="2"
          fill="rgba(16, 185, 129, 0.12)"
          className="backdrop-blur-[1px]"
        />
        
        {/* Subtle glass reflection highlight */}
        <path
          d="M14 10.5C14.8 9.8 16 9.4 17.2 9.5"
          stroke="#FFFFFF"
          strokeWidth="1.2"
          strokeLinecap="round"
          strokeOpacity="0.8"
        />

        {/* Magnifying glass handle */}
        <line
          x1="21.5"
          y1="17.5"
          x2="25.5"
          y2="21.5"
          stroke={accentHex}
          strokeWidth="2.2"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
};
