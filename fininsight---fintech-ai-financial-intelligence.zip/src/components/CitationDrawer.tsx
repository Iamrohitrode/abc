import React from 'react';
import { CitationInfo, AccentColor, ColorTheme } from '../types';
import { X, CheckCircle2, FileText, ExternalLink, ShieldCheck, Download, Copy, ChevronLeft, ChevronRight } from 'lucide-react';

interface CitationDrawerProps {
  citation: CitationInfo | null;
  onClose: () => void;
  accent: AccentColor;
  theme: ColorTheme;
}

export const CitationDrawer: React.FC<CitationDrawerProps> = ({
  citation,
  onClose,
  accent,
  theme
}) => {
  if (!citation) return null;

  const isDark = theme === 'dark-navy';
  const isEmerald = accent === 'emerald';

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className={`w-full max-w-xl h-full flex flex-col shadow-2xl border-l transition-all ${
          isDark
            ? 'bg-[#0A1020] border-[#1E2E48] text-slate-100'
            : 'bg-white border-slate-200 text-slate-900'
        }`}
      >
        {/* Header */}
        <div className={`p-4 border-b flex items-center justify-between ${isDark ? 'border-[#1C2638] bg-[#070C18]' : 'border-slate-200 bg-slate-50'}`}>
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-500/10 border border-red-500/20 flex items-center justify-center">
              <FileText className="w-4 h-4 text-red-500" />
            </div>
            <div>
              <h3 className="text-sm font-semibold truncate max-w-[280px]">
                {citation.documentName}
              </h3>
              <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
                <span>Page {citation.page}</span>
                <span>·</span>
                <span className="text-emerald-500 flex items-center gap-1 font-sans">
                  <CheckCircle2 className="w-3 h-3" />
                  Verified from source
                </span>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              aria-label="Close drawer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-5 space-y-5">
          {/* Audit Verification Card */}
          <div
            className={`p-4 rounded-xl border flex items-start gap-3 ${
              isDark
                ? 'bg-[#0E1A30]/80 border-emerald-500/30'
                : 'bg-emerald-50/70 border-emerald-200'
            }`}
          >
            <ShieldCheck className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
            <div className="text-xs space-y-1">
              <div className="font-semibold text-emerald-400 flex items-center gap-1.5">
                <span>Cryptographic Grounding Verified</span>
                <span className="font-mono text-[10px] px-1.5 py-0.2 rounded bg-emerald-500/20 text-emerald-300">
                  {citation.confidenceScore || 99.4}% match
                </span>
              </div>
              <p className="text-slate-300 leading-relaxed">
                Extracted verbatim from SEC Form 10-K filing Item 7 (MD&A). No synthetic hallucination detected across numerical statements.
              </p>
              <div className="text-[11px] font-mono text-slate-400 pt-1">
                Ref: {citation.auditRef || 'SEC_EDGAR_VERIFIED_P42'}
              </div>
            </div>
          </div>

          {/* Section Heading */}
          <div>
            <span className="text-[10px] font-mono uppercase tracking-wider text-slate-500">
              Filing Section
            </span>
            <h4 className="text-sm font-semibold mt-0.5 text-slate-200">
              {citation.sectionTitle || 'Consolidated Operational Performance & Segment Revenue'}
            </h4>
          </div>

          {/* Simulated PDF Page View */}
          <div
            className={`rounded-xl border p-5 shadow-inner relative overflow-hidden ${
              isDark
                ? 'bg-[#060A14] border-[#1C273D]'
                : 'bg-[#F9FAFB] border-slate-200'
            }`}
          >
            {/* Top Sheet Header */}
            <div className="flex items-center justify-between pb-3 mb-3 border-b border-slate-700/40 text-[11px] text-slate-400 font-mono">
              <span>FINANCIAL OVERVIEW — FY2024 FORM 10-K</span>
              <span>PAGE {citation.page} OF 148</span>
            </div>

            {/* Verbatim highlighted snippet */}
            <div className="relative pl-3 border-l-2 border-emerald-500 my-3">
              <p className="text-xs text-slate-300 leading-relaxed font-serif tracking-normal">
                "{citation.snippet}"
              </p>
            </div>

            {/* Extracted Metrics Table */}
            {citation.highlightedMetrics && (
              <div className="mt-4 pt-3 border-t border-slate-700/40">
                <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 block mb-2">
                  Audited Line Items (Page {citation.page})
                </span>
                <div className="grid grid-cols-2 gap-2 text-xs">
                  {citation.highlightedMetrics.map((item, idx) => (
                    <div
                      key={idx}
                      className={`p-2.5 rounded-lg border ${
                        isDark ? 'bg-[#0A1224] border-[#192742]' : 'bg-white border-slate-200'
                      }`}
                    >
                      <div className="text-[11px] text-slate-400">{item.label}</div>
                      <div className="font-mono font-semibold text-white mt-0.5">
                        {item.value}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Page Footer */}
            <div className="mt-5 pt-3 border-t border-slate-800 flex items-center justify-between text-[10px] text-slate-500">
              <span>Auditor: KPMG LLP (Consolidated)</span>
              <span>Doc Hash: e4b2..9f1a</span>
            </div>
          </div>
        </div>

        {/* Footer actions */}
        <div className={`p-4 border-t flex items-center justify-between ${isDark ? 'border-[#1C2638] bg-[#070C18]' : 'border-slate-200 bg-slate-50'}`}>
          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                navigator.clipboard.writeText(citation.snippet);
              }}
              className="px-3 py-1.5 text-xs rounded-lg border border-slate-700 text-slate-300 hover:text-white hover:bg-slate-800 transition-colors flex items-center gap-1.5"
            >
              <Copy className="w-3.5 h-3.5" />
              <span>Copy Citation</span>
            </button>
          </div>

          <button
            onClick={onClose}
            className={`px-4 py-1.5 text-xs font-semibold rounded-lg text-white ${
              isEmerald ? 'bg-emerald-600 hover:bg-emerald-500' : 'bg-sky-600 hover:bg-sky-500'
            }`}
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
